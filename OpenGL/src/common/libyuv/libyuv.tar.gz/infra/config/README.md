This folder contains libyuv project-wide configurations
for chrome-infra services.
